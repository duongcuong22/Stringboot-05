package com.example.springboot05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot05ApplicationTests {

    @Test
    void contextLoads() {
    }

}
